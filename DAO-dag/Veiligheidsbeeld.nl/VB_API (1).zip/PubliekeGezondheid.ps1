$token ="eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6Ik1HTHFqOThWTkxvWGFGZnBKQ0JwZ0I0SmFLcyIsImtpZCI6Ik1HTHFqOThWTkxvWGFGZnBKQ0JwZ0I0SmFLcyJ9.eyJhdWQiOiJhcGk6Ly81NDkxYTgwZi0zYjE0LTQxM2EtOTFkZi0xYTJlNzQ2ODI5MmQiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC8yNTUxMDc0My1mNDBjLTRlNjYtYTk0OC0xNGRmNTU5Zjk5YjAvIiwiaWF0IjoxNzE5Mzk1NzE1LCJuYmYiOjE3MTkzOTU3MTUsImV4cCI6MTcxOTM5OTYxNSwiYWlvIjoiRTJkZ1lOakVFSGR3SXhmVDVwLy9WTjlHWDFXUUFBQT0iLCJhcHBpZCI6ImMzZDIwNGE2LTZlNzctNGQwMC1iMmU3LWY1MjU3OTgzOGExZSIsImFwcGlkYWNyIjoiMSIsImlkcCI6Imh0dHBzOi8vc3RzLndpbmRvd3MubmV0LzI1NTEwNzQzLWY0MGMtNGU2Ni1hOTQ4LTE0ZGY1NTlmOTliMC8iLCJvaWQiOiI2MjU4ZTYwZi0yMWM1LTQzOGEtYTM0ZS05N2I4MjFlYTBlN2IiLCJyaCI6IjAuQVhrQVF3ZFJKUXowWms2cFNCVGZWWi1ac0Etb2tWUVVPenBCa2Q4YUxuUm9LUzBNQVFBLiIsInJvbGVzIjpbIkFQSS5Ub3BpY3MuV3JpdGUiLCJBUEkuVG9waWNzLlJlYWQiXSwic3ViIjoiNjI1OGU2MGYtMjFjNS00MzhhLWEzNGUtOTdiODIxZWEwZTdiIiwidGlkIjoiMjU1MTA3NDMtZjQwYy00ZTY2LWE5NDgtMTRkZjU1OWY5OWIwIiwidXRpIjoiTzd0azZGRGMxMDY0eGR3RWw3UWdBQSIsInZlciI6IjEuMCJ9.XoraUDuz5dMhby3IWsvG_cIYE15trM7S4_gRAvxlgFK84BXyG3gEXlYl5OE9da6IP7yTqjNKsj8rl1rOBGrdQUI-AI6G07EdAXsKQU26nNIoTYUdrZzdayBtbzVAhjgrvq4g4e83NhDI3BkMxRE7q7c5Wt8OBORthkz-lJEFyF40SMtOqNwHZ_5KXpnfTWrpNgVBdksqj2iQT99rxGgtr0FUAe0byVTbDOvTy0KAr4Z61ZfGN-GpPZDUsVIjaNxvsSpW2e92vwjxRDgcw_Fi3MVyNK_nUlBTXU7wEpYwkvl0rrae8IDVW4nxuO7scv8XQ2HcVazlslX8n_Tss60Aew"
###Write-Host "Bearer Token: $token"
##We need to create or onw ID

$apiEndpoint = "https://api.veiligheidsbeeld.nl/api/external/Topics/5faf9702-8287-4e9b-9b83-09f7d30ba306" # Replace with the API endpoint URL
write-host $apiEndpoint

$jsonPayload = '{
			"title": "Publieke gezondheidszorg",
			"isActive": true,
			"slug": "publieke-gezondheidszorg",
			"shortDescription": "Twente is aan het testen met de API",
			"rawContent": "<h1>Verkeer</h1><h2>Files</h2><p>Je kunt alleen een update doen via de API niet aanmaken</p>",
			"currentThreatLevel": 2,
			"maxThreatLevel": 4,
			"iconId": "4a638a9a-3b74-4330-b621-3bfca74157cd"
			}'

$headers = @{
    "Authorization" = "Bearer $token"
    "Content-Type" = "application/json"
}


    # Make the PUT request using Invoke-RestMethod
    $response = Invoke-RestMethod -Uri $apiEndpoint -Method Put -Headers $headers -Body $jsonPayload

    # Output the response (optional)
    Write-Host "PUT request successful. Response:"
    $response


