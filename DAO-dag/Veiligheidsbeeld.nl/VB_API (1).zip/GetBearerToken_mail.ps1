# Set the client ID and secret value
$clientID = "c3d204a6-6e77-4d00-b2e7-f52579838a1e"
$clientSecret = "BPj8Q~LlX1RclBATSQpGyY8Elnd2EyMj4G.vWb~j"
$scope = "api://5491a80f-3b14-413a-91df-1a2e7468292d/.default"
# Set the token endpoint URL
$tokenEndpoint = "https://login.microsoftonline.com/25510743-f40c-4e66-a948-14df559f99b0/oauth2/v2.0/token"

# Construct the authorization header with the client ID and secret
$base64Auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("$($clientID):$($clientSecret)"))
$authorizationHeader = "Basic $base64Auth"

# Set the token request parameters
$body = @{
    grant_type = "client_credentials"
	scope = $scope
}

# Send the token request and retrieve the response
$response = Invoke-RestMethod -Uri $tokenEndpoint -Method Post -Headers @{
    Authorization = $authorizationHeader
    "Content-Type" = "application/x-www-form-urlencoded"
} -Body $body

# Extract and display the bearer token
$token = $response.access_token
Write-Host "Bearer Token: $token"



#Get the topics

# Set the API endpoint URL
$apiEndpoint ="https://veiligheidsbeeld.nl/api/external/Topics?Regions=08db9327-d879-4620-895a-2c9279fcd150"
#$apiEndpoint ="https://veiligheidsbeeld.nl/api/external/Topics"
# Set the request headers
$headers = @{
    Authorization = "Bearer $token"
}

# Send the API request and retrieve the JSON response
$response = Invoke-RestMethod -Uri $apiEndpoint -Headers $headers

# Display the JSON response
$response | ConvertTo-Json
Write-host $response

